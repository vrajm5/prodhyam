from start import*
import matplotlib.pyplot as plt
import pandas as  pd 

x=(time)
y=(speed)
plt.plot(x,y)
plt.xlabel('time')
plt.ylabel('speed')

