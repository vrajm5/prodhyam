# Matplotlib Tutorial

Jupyter notebook and data files to go along with my YouTube video on how to visualize data with the matplotlib library of Python.
