import matplotlib.pyplot as plt 
import numpy as np
import pandas as pd 


print(len(x))
print(len(y))

plt.plot(x,y,color='purple',linestyle='--',marker='*')
#plt.scatter(x,y)
plt.show()
