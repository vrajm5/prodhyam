import serial as sr
import matplotlib.pyplot as plt 
import numpy as np

def speedPlot():

    s=sr.Serial('COM4',9600)

    s.close()
    s.open()
    plt.close('all')
    plt.figure()
    plt.ion()

    data=np.array([])
    i=0
    while i<100:
    
        a=s.readline()
        a.decode()
        b=float(a[0:4])
        data=np.append(data,b)

        
        plt.cla()
        plt.plot(data,label='Live Speed',marker='.',color='purple')
        plt.legend(loc='best')
        plt.xlabel('Time Interval (Secs) ')
        plt.ylabel('Instantaneous speed(Km/Hr)')

        plt.pause(0.01)
        

        i=i+1


speedPlot()

