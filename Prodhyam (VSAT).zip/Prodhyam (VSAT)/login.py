import matplotlib.pyplot as plt 
import numpy as np
import pandas as pd 
import csv


d=[100,90,82,73,64,55,46,40,32,22,10,1,1]
print(len(d))
c=[10,24,35,48,60,73,85,98,100,100,100,100,100]
print(len(c))
t=[0,15,30,45,60,75,90,105,120,135,150,175,180]
print(len(t))
a=plt.plot(t,c,color='purple',label='charging',marker='*',markersize=5,linestyle='-.')
b=plt.plot(t,d,color='green',label='discharging',marker='*',markersize=5,linestyle='-.')
plt.xlabel('Time Interval in Minutes')
plt.ylabel('Charging And Discharging of Battery')
plt.title('Charging And Discharging Graph')


plt.legend()
#plt.grid()
plt.legend(loc='right', frameon=False)
plt.show()