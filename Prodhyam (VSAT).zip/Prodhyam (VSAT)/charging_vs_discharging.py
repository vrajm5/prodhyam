# -*- coding: utf-8 -*-
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import math
import csv

def chargingGraph():
    charging=pd.read_csv('C:/Users/Vrrajjj M5/Desktop/The Transistor/Competitions/Hackstomp/Prodhyam (VSAT)/try1.csv')    
    x=charging.iloc[:,:-2].values
    y=charging.iloc[:,-1].values
    z=charging.iloc[:,1]


    plt.plot(x,z,color='purple',label='Discharging',linestyle='--',marker='*')
    plt.plot(x,y,color='green',label='charging',linestyle='--',marker='*')

    plt.title('Battery Usage Stats of Your Vehicle')
    plt.xlabel('Time(Minutes)')
    plt.ylabel('Charging(%) / Discharging(%)')
    axes = plt.gca()
    axes.yaxis.grid()
    plt.legend()
    plt.show()
#chargingGraph()