import mysql.connector



def connect():
    mydb=mysql.connector.connect(

        host='localhost',
        user='root',
        passwd='bmwm53552',
    )
    myCursor= mydb.cursor() 

def create_database():
    mydb=mysql.connector.connect(

        host='localhost',
        user='root',
        passwd='bmwm53552',
    )
    myCursor= mydb.cursor() 
    myCursor.execute('CREATE DATABASE speed')

def show_database():
    

    mydb=mysql.connector.connect(

        host='localhost',
        user='root',
        passwd='bmwm53552',
    )
    myCursor= mydb.cursor() 
    myCursor.execute('SHOW DATABASES')
    for db in myCursor:
        print(db)
    

# create_database()
# show_database()

def tables():
    mydb=mysql.connector.connect(

        host='localhost',
        user='root',
        passwd='bmwm53552',
        database='speed'
    )
    myCursor= mydb.cursor()
    myCursor.execute('CREATE TABLE IF NOT EXISTS speedVariation( time VARCHAR(25) , speed INTEGER(10))') 
    mydb.commit()
    mydb.close()

#tables()






