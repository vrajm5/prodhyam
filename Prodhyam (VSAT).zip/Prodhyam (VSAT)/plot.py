import mysql.connector

def createDatabase():

    mydb=mysql.connector.connect(

        host='localhost',
        user='root',
        passwd='bmwm53552',
        #database='pycode'
        
        )
    myCursor= mydb.cursor()
    myCursor.execute('CREATE DATABASE IF NOT EXISTS pycode')
    mydb.commit()
    mydb.close()

createDatabase()

def createTable():
    mydb=mysql.connector.connect(

        host='localhost',
        user='root',
        passwd='bmwm53552',
        database='pycode'
        
        )
    myCursor= mydb.cursor()





    myCursor.execute('CREATE TABLE IF NOT EXISTS usseregisteration (Name VARCHAR(45),VIN VARCHAR(45) \
        ,Blood_Group VARCHAR(45),Contact_Number VARCHAR(45),Emergency_Number VARCHAR(45) \
            ,State VARCHAR(45) ,City VARCHAR(45) ,Pincode VARCHAR(45))' ) 
            

    mydb.commit()
    mydb.close()

createTable()   