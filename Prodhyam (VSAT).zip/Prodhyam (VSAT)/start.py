from playsound  import playsound 
from gtts import gTTS
from backend import *
from datetime import datetime
import time
import random 
import sqlite3
import matplotlib.pyplot as plt 
import numpy as np
from tkinter import *

fo=open('speed.csv','r')
fh=fo.read()



now = datetime.now()

time = now.strftime("%H:%M:%S")
print(type(time))




def speedGenerator():
    global speed
    global randomlist
    randomlist=[]
    for i in  range(0,10):
        
        speed=random.randint(80,150)
        randomlist.append(speed)
        
        #print(randomlist)
        
    
    #print(speed)


def warning120(myText):
    audio120=gTTS(myText)
    audio120.save('warning120.mp3')
    
warning120('overspeeding')


def speed_120():
       
    playsound('warning120.mp3') #Warning Vocal Message
    # playsound('alert.mp3') #Warning sound
#========executions=========
def timeIncrease():
    global timeInterval
    timeInterval=[]
    for i in range(10): 
        a =  random.randint(0,10)
        timeInterval.append(a)
        timeInterval.sort()
        
    

def speed_conditions() :   
    if speed >=120:
        print('')
        print(f'The current speed = {speed} Km/hr')
        print('')


        speed_120()

    elif speed > 80:
        playsound('alert.mp3') 
        print(f'The current speed = {speed} Km/hr')

#=======running the loop for 10 times======
def loop():
    for j in range(10):
        
        speedGenerator()
        speed_conditions()
        timeIncrease()
        
        
        
    
        info=(time,speed)
            
           
        
        mydb=mysql.connector.connect(

            host='localhost',
            user='root',
            passwd='bmwm53552',
            database='speed'
        )
        myCursor= mydb.cursor()
        sql='INSERT INTO speedVariation(time,speed) VALUES(%s,%s)'
        myCursor.execute(sql,info)
        
        
        mydb.commit()
        mydb.close()
        #plt.plot(timeInterval,speed)
        
        
       
        
      

        


    

# plt.plot(randomlist,timeInterval)

        
        
        
        
loop()
plt.show()








    
