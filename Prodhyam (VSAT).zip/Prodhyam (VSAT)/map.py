import requests
import folium 

res=requests.get('https://ipinfo.io/')
data = res.json()
#print(data)

location = data['loc'].split(',')
latitude=float(location[0])
longitude=float(location[1])
pincode = data['postal']
place=data['city'].split(',')
print(f'Co-ordinates are latitude={latitude} , longitude={longitude}')
print(f'city={place} and pincode = {pincode}')

fg = folium.FeatureGroup('my map')
fg.add_child(folium.GeoJson(data=(open('india_states.json','r',encoding='UTF-8-sig').read())))

fg.add_child(folium.Marker(location=[latitude,longitude],popup='this is the site of emergency'))

map=folium.Map(location=[latitude,longitude],zoom_start=10)
map.add_child(fg)


map.save("locate.html")
print('file:///C:/Users/Vrrajjj%20M5/Desktop/python/sms%20project/locate.html')