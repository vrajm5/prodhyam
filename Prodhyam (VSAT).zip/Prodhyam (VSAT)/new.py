#IMPORTING THE LIBRARIES FROM PYTHON

from tkinter import *
from tkinter import ttk

import mysql.connector





        



#Creating Root class for TKINTER LIBRARY

window = Tk()
window.title("Vehicle Configuation")
window.geometry('1000x1000')
window.configure(background = "grey")



# canvas = Canvas(window, width = 300, height = 300)      
# canvas.grid(row=0,column=16)      
# img = PhotoImage(file="transistor logo.png")      
# im_temp = im_temp.resize((250, 250), Image.ANTIALIAS)


# canvas.create_image(20,20, anchor=NW, image=img)    


#========== CREATING LABELS ==============

#Label Widgets

userNameLabel = Label(window ,text = "Full Name")
userNameLabel.grid(row = 0,column = 0)

vehicleNumberLabel = Label(window ,text = "Vehicle Number")
vehicleNumberLabel.grid(row = 2,column = 0)

bloodGroupLabel = Label(window ,text = "Blood Group")
bloodGroupLabel.grid(row = 4,column = 0)

contactNumberLabel = Label(window ,text = "Contact Number")
contactNumberLabel.grid(row = 6,column = 0)

emergencyNumberLabel =  Label(window ,text = "Emergency Number")
emergencyNumberLabel.grid(row = 8,column = 0)

stateLabel =  Label(window ,text = "State")
stateLabel.grid(row = 10,column = 0)

cityLabel =  Label(window ,text = "City")
cityLabel.grid(row = 12,column = 0)


pincodeLabel =  Label(window ,text = "Pincode")
pincodeLabel.grid(row = 14,column = 0)

#User Entries
#================ MENTIONING THE DATATYPES OF INPUT VARIABLES============

userNameEntry=StringVar()
vehicleNumberEntry = StringVar()
bloodGroupEntry=StringVar()
contactNumberEntry=StringVar()
emergencyNumberEntry=StringVar()
stateEntry=StringVar()
cityEntry=StringVar()
pincodeEntry=StringVar()

#=========== Defining the INPUT FIELDS=============


e1 = Entry(window,textvariable=userNameEntry)
e1.grid(row = 0,column = 1)

e2 = Entry(window,textvariable=vehicleNumberEntry)
e2.grid(row = 2,column = 1)

e3= Entry(window,textvariable=bloodGroupEntry)
e3.grid(row = 4,column = 1)

e4 = Entry(window,textvariable=contactNumberEntry)
e4.grid(row = 6,column = 1)

e5 = Entry(window,textvariable=emergencyNumberEntry)
e5.grid(row = 8,column = 1)

e6 = Entry(window,textvariable=stateEntry)
e6.grid(row = 10,column = 1)

e7= Entry(window,textvariable=cityEntry)
e7.grid(row = 12,column = 1)

e8= Entry(window,textvariable=pincodeEntry)
e8.grid(row = 14,column = 1)





    
    
    
    
    
    
    
    
    




def insert_data():

    userName= userNameEntry.get()
    vehicleNumber=vehicleNumberEntry.get()
    bloodGroup=bloodGroupEntry.get()
    contactNumber=contactNumberEntry.get()
    emergencyNumber=emergencyNumberEntry.get()
    state=stateEntry.get()
    city=cityEntry.get()
    pincode=pincodeEntry.get()
   
#    # USING THE GET METHOD TO GET THE VALUES FROM THE INPUT FIELDS
   

    
#     #INITIALIZING THE CONNECTION TO THE MYSQL DATABASE

    mydb=mysql.connector.connect(

        host='localhost',
        user='root',
        passwd='bmwm53552',
        database='pycode'
        
        )

        #CREATING CURSOR OBJECT FOR EXECUTING QUERIES

    myCursor= mydb.cursor()

    # EXECUTING THE QUERIES USING EXECUTE METHOD AND TUPLES

    myCursor.execute('INSERT INTO userregisteration (Name,VIN,Blood_Group,Contact_Number,Emergency_Number,State,City,Pincode) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)',

    (   userName,
        vehicleNumber,
        bloodGroup,
        contactNumber,
        emergencyNumber,
        state,
        city,
        pincode,



    )
    
    )



    mydb.commit()  #SAVING THE CHANGES IN THE TABLES
    mydb.close()    #CLOSING THE CONNECTION TO MYSQL
    print(userName)
    
userName= userNameEntry.get()
vehicleNumber=vehicleNumberEntry.get()
bloodGroup=bloodGroupEntry.get()
contactNumber=contactNumberEntry.get()
emergencyNumber=emergencyNumberEntry.get()
state=stateEntry.get()
city=cityEntry.get()
pincode=pincodeEntry.get()

print('USerName is',userName)


    
    
    


#CREATING THE SUBMIT BUTTON
btn = ttk.Button(window ,text="Submit",command=insert_data).grid(row=16,column=1)

window.mainloop() #TERMINATING THE GUI LOOP












