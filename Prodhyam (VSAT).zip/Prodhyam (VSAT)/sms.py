import requests
import json
import time
from tkinter import *
from tkinter.messagebox import showinfo,showerror
import mysql.connector
import datetime
import urllib.request 
from map import *





mydb=mysql.connector.connect(
	host='localhost',
	user='root',
	passwd='bmwm53552',
    database='database1',
)

t = time.localtime()
current_time = time.strftime("%H:%M:%S", t)
print(current_time)
time=current_time

date=datetime.datetime.now().strftime("%Y-%m-%d")
print(date)

mycursor=mydb.cursor()


def send_sms(number,message):
    url='https://www.fast2sms.com/dev/bulk'
    params={
        'authorization':'itSyDVX57cgsvdTb1WqL9QEamH486Pkz3RA0rhNopUMYx2BeIGvIjoUelRLYg61xWhuVnaQNXkcyBzqf',
        'sender_id':'FSTSMS',
        'message':message,
        'language':'English',
        'route':'p',
        'numbers':number


    }

    response=requests.get(url, params=params)
    dic=response.json()
    print(dic)
    return dic.get('return')




#creating on click function

def btnclick():
    num = textNumber.get()
    msg = textMsg.get('1.0','5000.0')

    

    r   = send_sms(num,msg)     #calling the sms function
    
    if r:
        showinfo('Success!!','message delivered successfully')
        sqlFormula='INSERT INTO users(num,time,date) VALUES (%s,%s,%s)'
        
        info=(num,time,date)
        
        mycursor.execute(sqlFormula,(info))
        mydb.commit()
        print(num)
        
    
    
    else:
         showerror('Awww Snapp','Something went wrong')

#mycursor.execute('CREATE TABLE info (number varchar(20),time varchar(20))')


def crashMsg():
    
    emergencyNumber=emergencyNumberEntry.get()
    emergencyMessage=f'Your Relative {userName} with Vehicle number {vehicleNumber} is \
                        in emergency at the following Location :{latitude},{longitude} \
                            {pincode} , {place}'            
    roadSideMessage=f'A Vehicle {vehicleNumber} has someEmergency at following Loc \
                        {latitude},{longitude} \
                            {pincode} , {place}'


    w  = send_sms(emergencyNumber,emergencyMessage) 
    rsa= send_sms(9224551878,roadSideMessage)
   
    if w or rsa:
        showinfo('Relax!!,Someone will reachout to youu very soon :)')

    else:
        showerror('There Seems to be a Network Issue')


#Creating Gui

#creating a main tkinter object

root = Tk()
root.title('Contact RoadSide Assistance') 
root.geometry('400x550') #dimensions of the box
root.configure(bg='#8a07b5')
font=('Helvetica',22,'bold') #font and style of the box

#NUMBER FIELD

textNumber=Entry(root,font=font) #for inputing the number field
textNumber.pack(fill=X,pady=25) #toggling about the axis
textNumber.configure(background='#9ed4e8')


#MESSAGE FIELD

textMsg=Text(root)

textMsg.pack(fill=X)

#=========location field and link=============


textLoc=Text(root)
textLoc.pack(fill=X )



# ==========creating buttons=============
#locBtn = Button(root,text='SEND LOC')
sendBtn = Button(root,text='SEND MESSAGE',command=btnclick)
sendBtn.pack()
root.mainloop() #main looop that executes it 
