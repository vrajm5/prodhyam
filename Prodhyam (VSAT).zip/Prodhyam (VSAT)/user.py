# import mysql.connector 
# import time

# def connect():
#     mydb=mysql.connector.connect(

#             host='localhost',
#             user='root',
#             passwd='bmwm53552',
            
#         )
#     myCursor= mydb.cursor()
#     #myCursor.execute('CREATE DATABASE pycode')
#     for db in myCursor:
#         print(db)
    
#     myCursor.execute('SHOW DATABASES')
#     mydb.commit()
#     mydb.close()
    

# connect()



# def user():
#     gender = input('Please Select Your Gender (M/F) : ')
#     gender.lower()
#     if gender=='m':
#         name=input('Please Enter your Name dear Sir : ')

#         print(f'Hello {name} Sir, Welcome to BMW Family') 
#         time.sleep(3)
#         print('Let us Configure your BMW 7-Series')

        

#     else:
#         name=input("Please Enter your Name followed by Surname Ma'am :" )

#         print(f'Hello Ma\'am {name} , Welcome to BMW Family') 
#         time.sleep(3)
#         print('Let us Configure your BMW 7-Series')
#     contNumber = int(input('Please Enter your Contact Number : '))
#     relNumber = int(input('Please Enter your Friend\'s Contact Number in case of any Emergency : '))
#     bloodGroup = input('Please Enter your Blood Group : ')
    
#     vehicleNumber = input("Please Enter your Vehicle Number :" )
#     state = input('Please Enter your State : ')
#     city = input('Please Enter your city : ')
#     pincode = input('Please Enter your pincode')

#     if gender=='m':
#         print(' ')
#         print(f'Thank you for your Co-Operation {name} Sir , We Are pleased to have you as a part of BMW Family')
#         print(' ')
#         print('Please have a look at the User\'s Manual before Operating This vehicle')
#         print('Please wear seat belts while driving!')
#     else :
#         print(' ')
#         print(f'Thank you for your Co-Operation {name} ma\'am , We Are pleased to have you as a part of BMW Family')
#         print(' ')
#         print('Please have a look at the User\'s Manual before Operating This vehicle')
#         print('Please wear seat belts while driving!')
    

    
# user()




