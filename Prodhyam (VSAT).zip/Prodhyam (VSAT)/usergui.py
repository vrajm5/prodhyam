#IMPORTING THE LIBRARIES FROM PYTHON
from tkinter import messagebox
from tkinter import *
from tkinter import ttk
#from PIL import image
import mysql.connector
from  charging_vs_discharging import *
from randspeed import * 
from arduino import *
from sms import *





        



#Creating Root class for TKINTER LIBRARY

window = Tk()
window.title("Vehicle Configuation")
window.geometry('400x300')
window.configure(background = "#7d2ab5")






#========== CREATING LABELS ==============

#Label Widgets

userNameLabel = Label(window ,text = "Full Name")
userNameLabel.grid(row = 0,column = 3)

vehicleNumberLabel = Label(window ,text = "Vehicle Number")
vehicleNumberLabel.grid(row = 2,column = 3)

bloodGroupLabel = Label(window ,text = "Blood Group")
bloodGroupLabel.grid(row = 4,column = 3)

contactNumberLabel = Label(window ,text = "Contact Number")
contactNumberLabel.grid(row = 6,column = 3)

emergencyNumberLabel =  Label(window ,text = "Emergency Number")
emergencyNumberLabel.grid(row = 8,column = 3)

stateLabel =  Label(window ,text = "State")
stateLabel.grid(row = 10,column = 3)

cityLabel =  Label(window ,text = "City")
cityLabel.grid(row = 12,column = 3)


pincodeLabel =  Label(window ,text = "Pincode")
pincodeLabel.grid(row = 14,column = 3)

#User Entries
#================ MENTIONING THE DATATYPES OF INPUT VARIABLES============

userNameEntry=StringVar()
vehicleNumberEntry = StringVar()
bloodGroupEntry=StringVar()
contactNumberEntry=StringVar()
emergencyNumberEntry=StringVar()
stateEntry=StringVar()
cityEntry=StringVar()
pincodeEntry=StringVar()

#=========== Defining the INPUT FIELDS=============


e1 = Entry(window,textvariable=userNameEntry)
e1.grid(row = 0,column = 6)

e2 = Entry(window,textvariable=vehicleNumberEntry)
e2.grid(row = 2,column = 6)

e3= Entry(window,textvariable=bloodGroupEntry)
e3.grid(row = 4,column = 6)

e4 = Entry(window,textvariable=contactNumberEntry)
e4.grid(row = 6,column = 6)

e5 = Entry(window,textvariable=emergencyNumberEntry)
e5.grid(row = 8,column = 6)

e6 = Entry(window,textvariable=stateEntry)
e6.grid(row = 10,column = 6)

e7= Entry(window,textvariable=cityEntry)
e7.grid(row = 12,column = 6)

e8= Entry(window,textvariable=pincodeEntry)
e8.grid(row = 14,column = 6)

userName = userNameEntry.get()
vehicleNumber=vehicleNumberEntry.get()
bloodGroup=bloodGroupEntry.get()
contactNumber=contactNumberEntry.get()
emergencyNumber=emergencyNumberEntry.get()
state=stateEntry.get()
city=cityEntry.get()
pincode=pincodeEntry.get()


def insert_data():
   
   # USING THE GET METHOD TO GET THE VALUES FROM THE INPUT FIELDS


  
    
    
    #INITIALIZING THE CONNECTION TO THE MYSQL DATABASE

    mydb=mysql.connector.connect(

        host='localhost',
        user='root',
        passwd='bmwm53552',
        database='pycode'
        
        )

        #CREATING CURSOR OBJECT FOR EXECUTING QUERIES

    myCursor= mydb.cursor()

    # EXECUTING THE QUERIES USING EXECUTE METHOD AND TUPLES

    myCursor.execute('INSERT INTO userregisteration \
    (Name,VIN,Blood_Group,Contact_Number,Emergency_Number,State,City,Pincode) \
         VALUES(%s,%s,%s,%s,%s,%s,%s,%s)',

    (   userName,
        vehicleNumber,
        bloodGroup,
        contactNumber,
        emergencyNumber,
        state,
        city,
        pincode,



    )
    
    )
    
    # if userNameEntry.get() or vehicleNumberEntry.get()  or contactNumberEntry.get() or emergencyNumberEntry.get() or stateEntry.get() or cityEntry.get() or pincodeEntry.get() == '':
    #     messagebox.showerror('Registeration Failed','All Fields are Mandatory')
    
    # else:

    messagebox.showinfo('Success','Registeration SuccessFull')    
          #CLOSING THE CONNECTION TO MYSQL


    mydb.commit()  #SAVING THE CHANGES IN THE TABLES
    mydb.close()  


    

def nextScreen():   
    # if userNameEntry.get() or vehicleNumberEntry.get()  or contactNumberEntry.get() or emergencyNumberEntry.get() or stateEntry.get() or cityEntry.get() or pincodeEntry.get() == ' ':
    #     messagebox.showerror('Registeration Failed','All Fields are Mandatory')
    # else:
    messagebox.showinfo('Success')

    window1 = Tk()
    window1.title("View Statics of car")
    window1.geometry('400x400')
    window1.configure(background = "black")

    #Label widgets
    batteryStatusLabel = Label(window1 ,text = "Logged in as")
    batteryStatusLabel.grid(row = 0,column = 0)

    speedVariationLabel = Label(window1 ,text = "Phone Number")
    speedVariationLabel.grid(row = 2,column = 0)

    loginName = Label(window1,text= userName)
    loginName.grid(row = 0,column = 1)

    phoneNumber = Label(window1,text = 'contactNumber')
    phoneNumber.grid(row = 2,column = 1)

    btn1 =ttk.Button(window1 ,text="Click For SpeedVariations",command=speedModule).grid(row=16,column=1)
    btn2 = ttk.Button(window1 ,text="Click For Battery Charging Status ",command=chargingGraph).grid(row=20,column=1)
    btn3= ttk.Button(window1 ,text="Click For RoadSide 24*7 Assistance ",command=crashMsg).grid(row=22,column=1)
    btn4= ttk.Button(window1 ,text="Click For Live Speed Graph ",command=speedPlot).grid(row=24,column=1)
    
    

    window1.mainloop()



btn = ttk.Button(window ,text="Submit",command=insert_data).grid(row=22,column=6)
btnNext = ttk.Button(window ,text="Click to Proceed",command=nextScreen).grid(row=28,column=6)


#CREATING THE SUBMIT BUTTON


window.mainloop()


 #TERMINATING THE GUI LOOP












